<?php

    function custombrokemodule){
        echo "<p>Hi! I'm Custom Broke Module >_</p>";
    }

    add_modules("custombrokemodule", "Area-5");