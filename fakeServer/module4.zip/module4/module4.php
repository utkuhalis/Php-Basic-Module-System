<?php

    function module4(){
        echo "<p>Hi! I'm Module4</p>";
    }

    add_modules("module4", "Area2");