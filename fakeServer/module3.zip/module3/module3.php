<?php

    function module3(){
        echo "<p>Hi! I'm Module3</p>";
    }

    add_modules("module3", "Area3");