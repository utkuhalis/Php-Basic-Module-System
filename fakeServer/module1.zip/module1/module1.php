<?php

    function module1(){
        echo "<p>Hi! I'm Module1</p>";
    }

    add_modules("module1", "Area1");