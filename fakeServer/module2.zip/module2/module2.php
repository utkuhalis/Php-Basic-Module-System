<?php

    function module2(){
        echo "<p>Hi! I'm Module2</p>";
    }

    add_modules("module2", "Area2");