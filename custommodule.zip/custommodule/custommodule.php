<?php

    function custommodule(){
        echo "<p>Hi! I'm Custom Module >_</p>";
    }

    add_modules("custommodule", "Area3");